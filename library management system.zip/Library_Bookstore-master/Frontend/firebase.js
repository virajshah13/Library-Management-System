var app_fireBase = {};
(function () {
  var firebaseConfig = {
    apiKey: "AIzaSyDHJ_-ZQYPFVq7-NtsJXXMFKnga9dxGpVM",
    authDomain: "library-20343.firebaseapp.com",
    projectId: "library-20343",
    storageBucket: "library-20343.appspot.com",
    messagingSenderId: "212815264632",
    appId: "1:212815264632:web:a934e86c5eb179e911e68d",
    measurementId: "G-9EELX46W32",
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  app_fireBase = firebase;
})();
